var dir_fe219fca207b878205c0dd92278d118b =
[
    [ "arpa", "dir_6b1b06896a870ebfb9c854c4c71f4ff5.html", "dir_6b1b06896a870ebfb9c854c4c71f4ff5" ],
    [ "net", "dir_c62aba36f6630fea5cd7fe1c941850d4.html", "dir_c62aba36f6630fea5cd7fe1c941850d4" ],
    [ "sys", "dir_8da39adb2a11af660bdd7075b7323870.html", "dir_8da39adb2a11af660bdd7075b7323870" ],
    [ "netdb.h", "compat_2posix_2netdb_8h.html", null ]
];