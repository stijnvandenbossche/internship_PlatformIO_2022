var group__lwip__opts__dns =
[
    [ "DNS_DOES_NAME_CHECK", "group__lwip__opts__dns.html#ga07ffd8e9106dae3b65347bd03811a4b6", null ],
    [ "DNS_LOCAL_HOSTLIST", "group__lwip__opts__dns.html#gacba1ac491c1b47b98dfbd0d5c1662659", null ],
    [ "DNS_LOCAL_HOSTLIST_IS_DYNAMIC", "group__lwip__opts__dns.html#ga8235a5fb0a1c1cceeee670cf95612ba8", null ],
    [ "DNS_MAX_NAME_LENGTH", "group__lwip__opts__dns.html#ga3b01c79902063c170ef57deb72f56124", null ],
    [ "DNS_MAX_RETRIES", "group__lwip__opts__dns.html#gaab73c241189335435f3f662aa6a00dba", null ],
    [ "DNS_MAX_SERVERS", "group__lwip__opts__dns.html#ga9f9881c887a8aceb9765820c2dbdf292", null ],
    [ "DNS_TABLE_SIZE", "group__lwip__opts__dns.html#ga2384e76c1acdf969d883f3de08d340f7", null ],
    [ "LWIP_DNS", "group__lwip__opts__dns.html#ga98710dd81446b7cb2daac736bae6f646", null ],
    [ "LWIP_DNS_SECURE", "group__lwip__opts__dns.html#ga8979c30dfbfde609d5139f80aabdfcc5", null ],
    [ "LWIP_DNS_SUPPORT_MDNS_QUERIES", "group__lwip__opts__dns.html#gafcbde5706a70ace562bd1f7d2d6f77cb", null ]
];