var group__netbiosns =
[
    [ "Options", "group__netbiosns__opts.html", "group__netbiosns__opts" ],
    [ "netbiosns_init", "group__netbiosns.html#ga0c696ea25a79e97715c8217901cff66b", null ],
    [ "netbiosns_stop", "group__netbiosns.html#gaf82174943d25d67b04d44b7fba808806", null ]
];