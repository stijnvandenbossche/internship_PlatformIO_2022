
/*Board version*/
#define CONFIG_LCD_PAD_ESP32_S2_KALUGA_V1_3
/*LCD version*/
#define CONFIG_LCD_ST7789